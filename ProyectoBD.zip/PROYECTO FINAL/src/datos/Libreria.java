package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Libreria {

    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/VETERINARIA"; 
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        try (Connection connection = conectarMySQL()) {
            if (connection != null) {
                System.out.println("Conexión exitosa a MySQL");
            } else {
                System.out.println("No se pudo conectar a MySQL");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Connection conectarMySQL() throws SQLException {
        try {
            Class.forName(JDBC_DRIVER);
            return DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Controlador JDBC no encontrado", e);
        }
    }
}
