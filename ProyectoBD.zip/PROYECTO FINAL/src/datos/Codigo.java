package datos;

import vista.VeterinariaMenu;

import java.util.Arrays;
import java.util.Map;

public class Codigo {

    public static void main(String[] args) {
        VeterinariaMenu.ingresarDatosCliente();

        String[] productos = {"Juguete para Gato", "Correa para Perro", "Comida para Pájaros", "Champú para Perro"};
        Map<String, Integer> productosSeleccionados = VeterinariaMenu.mostrarCatalogoProductos(productos);

        if (VeterinariaMenu.preguntarAdopcionMascota()) {
            System.out.println("----- Selección de Mascota -----");
            String animalSeleccionado = VeterinariaMenu.seleccionarAnimal(Arrays.asList("Perro", "Gato", "Pez", "Loro"));
            if (animalSeleccionado != null) {
                System.out.println("¡Felicidades! Ha adoptado a un " + animalSeleccionado);
            } else {
                System.out.println("No se realizó la adopción de mascota.");
            }
        } else {
            System.out.println("No se realizó la adopción de mascota.");
        }

        String formaPago = VeterinariaMenu.preguntarFormaPago();
        if ("tarjeta".equalsIgnoreCase(formaPago)) {
            VeterinariaMenu.formularioPagoTarjeta();
        }

        VeterinariaMenu.generarBoleta(productosSeleccionados);

        VeterinariaMenu.mostrarAgradecimiento();
    }
}
