package vista;

import java.util.*;

public class VeterinariaMenu {

    private static final Scanner scanner = new Scanner(System.in);

    public static void ingresarDatosCliente() {
        System.out.println("----- Ingresar Datos del Cliente -----");
        System.out.print("Nombres: ");
        String nombre = scanner.nextLine();
        System.out.print("Apellidos: ");
        String apellido = scanner.nextLine();
        System.out.print("Celular: ");
        String celular = scanner.nextLine();
        System.out.print("DNI: ");
        String dni = scanner.nextLine();

        System.out.println("Datos del Cliente Ingresados:");
        System.out.println("Nombres: " + nombre);
        System.out.println("Apellidos: " + apellido);
        System.out.println("Celular: " + celular);
        System.out.println("DNI: " + dni);
    }

    public static Map<String, Integer> mostrarCatalogoProductos(String[] productos) {
        Map<String, Double> preciosProductos = obtenerPreciosProductos();
        Map<String, Integer> seleccionProductos = new HashMap<>();

        System.out.println("----- Catálogo de Productos -----");

        for (String producto : productos) {
            double precio = preciosProductos.get(producto);
            System.out.print(producto + " - Precio: $" + precio + " | Seleccione la cantidad: ");
            int cantidad = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer
            seleccionProductos.put(producto, cantidad);
        }

        return seleccionProductos;
    }

    public static boolean preguntarAdopcionMascota() {
        System.out.print("¿Desea adoptar una mascota? (Sí/No): ");
        String respuesta = scanner.nextLine().toLowerCase();

        return respuesta.equals("sí");
    }

    public static String seleccionarAnimal(List<String> tiposMascotas) {
        System.out.println("----- Selección de Mascota -----");
        System.out.println("Tipos de mascotas disponibles para adopción:");

        for (int i = 0; i < tiposMascotas.size(); i++) {
            System.out.println((i + 1) + ". " + tiposMascotas.get(i));
        }

        System.out.print("Seleccione el número del tipo de mascota que desea adoptar: ");
        int seleccion = scanner.nextInt();
        scanner.nextLine(); 

        if (seleccion >= 1 && seleccion <= tiposMascotas.size()) {
            return tiposMascotas.get(seleccion - 1);
        } else {
            System.out.println("Opción no válida. No se realizará la adopción de mascota.");
            return null;
        }
    }

    public static String preguntarFormaPago() {
        System.out.print("¿Cómo desea pagar? (Efectivo/Tarjeta): ");
        return scanner.nextLine();
    }

    public static void formularioPagoTarjeta() {
        System.out.println("----- Formulario de Pago con Tarjeta -----");
        System.out.print("Número de Tarjeta: ");
        String numeroTarjeta = scanner.nextLine();
        System.out.print("Nombre del Titular: ");
        String nombreTitular = scanner.nextLine();
        System.out.print("Fecha de Expiración (MM/YY): ");
        String fechaExpiracion = scanner.nextLine();
        System.out.print("CVV: ");
        String cvv = scanner.nextLine();
        System.out.println("Pago con tarjeta procesado con éxito.");
    }

    public static void generarBoleta(Map<String, Integer> productosSeleccionados) {
        System.out.println("----- Boleta de Compra -----");
        double total = 0;

        for (Map.Entry<String, Integer> entry : productosSeleccionados.entrySet()) {
            String producto = entry.getKey();
            int cantidad = entry.getValue();
            double precio = obtenerPreciosProductos().get(producto);

            double subtotal = precio * cantidad;
            System.out.println(producto + " x " + cantidad + " - Subtotal: $" + subtotal);
            total += subtotal;
        }

        System.out.println("Total a pagar: $" + total);
    }

    public static void mostrarAgradecimiento() {
        System.out.println("¡Gracias por su compra! Vuelva pronto.");
    }

    private static Map<String, Double> obtenerPreciosProductos() {
        Map<String, Double> precios = new HashMap<>();
        precios.put("Juguete para Gato", 15.99);
        precios.put("Correa para Perro", 12.50);
        precios.put("Comida para Pájaros", 8.99);
        precios.put("Champú para Perro", 9.75);
        return precios;
    }
}


